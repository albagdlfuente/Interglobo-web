<?php


if ( !defined( 'VIBE_CHILD_URL' ) )
define('VIBE_CHILD_URL',get_stylesheet_directory_uri());

if ( !defined( 'VIBE_CHILD_PATH' ) )
define('VIBE_CHILD_PATH',get_theme_root().'/wplmschild');
