<?php

// Essentials
include_once 'includes/config.php';
include_once 'includes/register.php';
include_once 'setup/setup.php';

?>
